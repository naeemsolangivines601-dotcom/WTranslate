package com.wtranslate.app

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * Handles on-device (offline) English -> Urdu translation using ML Kit.
 * The language model is downloaded once (needs internet the first time);
 * after that, all translation happens fully on-device with no network calls.
 */
object TranslatorHelper {

    private var translator: Translator? = null

    private fun getTranslator(): Translator {
        if (translator == null) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.URDU)
                .build()
            translator = Translation.getClient(options)
        }
        return translator!!
    }

    /**
     * Downloads the Urdu model over Wi-Fi if it isn't already on the device.
     * Call this once from MainActivity before relying on the service.
     */
    fun downloadModel(onSuccess: () -> Unit, onFailure: (Exception) -> Unit) {
        val conditions = DownloadConditions.Builder()
            .requireWifi()
            .build()
        getTranslator().downloadModelIfNeeded(conditions)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { onFailure(it) }
    }

    /**
     * Translates the given text. If the model isn't downloaded yet, ML Kit
     * will attempt to download it first (needs internet at that point only).
     */
    fun translate(text: String, onResult: (String) -> Unit, onError: (Exception) -> Unit) {
        val conditions = DownloadConditions.Builder()
            .allowMobileData()
            .build()
        getTranslator().downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                getTranslator().translate(text)
                    .addOnSuccessListener { translated -> onResult(translated) }
                    .addOnFailureListener { e -> onError(e) }
            }
            .addOnFailureListener { e -> onError(e) }
    }

    fun close() {
        translator?.close()
        translator = null
    }
}
