package com.wtranslate.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Listens only inside the WhatsApp app (see accessibility_service_config.xml).
 * When the user taps a message bubble's text, it grabs that text, sends it to
 * TranslatorHelper, and shows the Urdu result in a floating bubble near the tap.
 */
class WhatsAppAccessibilityService : AccessibilityService() {

    private lateinit var overlayManager: OverlayManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        overlayManager = OverlayManager(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return

        val node = event.source ?: return
        val text = extractMessageText(node)
        node.recycle()

        if (text.isNullOrBlank() || text.length < 2) return
        // Skip text that looks like it's already Urdu/Arabic script.
        if (containsArabicScript(text)) return

        val bounds = Rect()
        event.source?.getBoundsInScreen(bounds)

        TranslatorHelper.translate(
            text = text,
            onResult = { translated ->
                overlayManager.showTranslation(
                    translated,
                    anchorX = bounds.left,
                    anchorY = bounds.bottom
                )
            },
            onError = { e ->
                Log.e("WTranslate", "Translation failed: ${e.message}")
            }
        )
    }

    /**
     * WhatsApp's message bubble is usually a TextView carrying the message body.
     * We walk a couple of levels in case the click lands on a parent container.
     */
    private fun extractMessageText(node: AccessibilityNodeInfo): String? {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth < 4) {
            val nodeText = current.text?.toString()
            if (!nodeText.isNullOrBlank()) return nodeText
            current = current.parent
            depth++
        }
        return null
    }

    private fun containsArabicScript(text: String): Boolean {
        return text.any { it.code in 0x0600..0x06FF }
    }

    override fun onInterrupt() {
        // No-op
    }
}
