package com.wtranslate.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)

        findViewById<Button>(R.id.btnDownloadModel).setOnClickListener {
            Toast.makeText(this, "Urdu model download ho raha hai...", Toast.LENGTH_SHORT).show()
            TranslatorHelper.downloadModel(
                onSuccess = {
                    Toast.makeText(this, "Urdu model ready hai (offline)", Toast.LENGTH_SHORT).show()
                    updateStatus()
                },
                onFailure = { e ->
                    Toast.makeText(this, "Download fail: ${e.message}", Toast.LENGTH_LONG).show()
                }
            )
        }

        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission pehle se hai", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnAccessibilityPermission).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(
                this,
                "Settings mein 'WTranslate' service dhoondein aur ON karein",
                Toast.LENGTH_LONG
            ).show()
        }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        statusText.text = if (overlayOk) {
            "Overlay permission: OK. Ab Accessibility Service on karein aur WhatsApp kholein."
        } else {
            "Overlay permission abhi nahi di gayi."
        }
    }
}
