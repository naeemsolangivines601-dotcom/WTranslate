package com.wtranslate.app

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/**
 * Draws a small floating bubble on top of WhatsApp showing the Urdu translation.
 * Requires the "Display over other apps" (SYSTEM_ALERT_WINDOW) permission.
 */
class OverlayManager(private val context: Context) {

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null

    fun showTranslation(text: String, anchorX: Int, anchorY: Int) {
        hide() // remove any existing bubble first

        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.overlay_translate, null)
        val textView = view.findViewById<TextView>(R.id.overlayTranslatedText)
        textView.text = text

        val overlayType =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = anchorX
        params.y = anchorY

        // Tap the bubble to dismiss it
        view.setOnClickListener { hide() }

        windowManager.addView(view, params)
        overlayView = view
    }

    fun hide() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // view was already removed, ignore
            }
        }
        overlayView = null
    }
}
