# WTranslate — WhatsApp English→Urdu Offline Translator

## Ye kya karta hai
WhatsApp mein kisi English message par tap karne se ek floating bubble mein
uska Urdu translation dikhta hai. Translation Google **ML Kit** ke on-device
model se hota hai — pehli baar Urdu model download karne ke baad, sab kuch
bilkul offline chalta hai, internet ki zaroorat nahi.

## FREE APK banane ka sabse asaan tareeqa (bina Android Studio install kiye)

Ye project ek **GitHub Actions** workflow ke sath aata hai (`.github/workflows/build-apk.yml`)
jo GitHub ke apne free servers par asal APK bana kar deta hai. Bilkul free, koi
$25 ya koi bhi payment nahi.

1. https://github.com par free account banayein (agar nahi hai).
2. Naya **repository** banayein (public, koi bhi naam, e.g. "wtranslate").
3. Is poore `WTranslate` folder ke andar ke saare files/folders us repository
   mein upload kar dein (GitHub website par "Add file → Upload files" se
   sab kuch drag-drop kar sakte hain — poora folder structure maintain rahega
   agar aap zip ko pehle extract karke sab files ek sath select karein).
4. Upload ke baad GitHub Actions khud-b-khud chalna shuru ho jayega
   (ya agar na chale to repo ke **"Actions"** tab mein jayein aur
   "Build APK" workflow ko **Run workflow** button se manually chalayein).
5. 3-5 minute intezar karein — build chal rahi hogi.
6. Jab build khatam (green tick ✅) ho jaye, us run par click karein,
   neeche **"Artifacts"** section mein `WTranslate-debug-apk` milega —
   ise download kar lein (ye ek zip hoga jisme APK hoga).
7. Ye APK file apne Android phone par bhej dein (WhatsApp/email/USB se),
   phone par tap karke install kar lein. Phone mein "Install from unknown
   sources" allow karna par sakta hai — ye sirf ek normal Android
   security prompt hai, koi payment ya Play Store involved nahi.

Is tareeqe se aapko kabhi Android Studio install karne ya kuch pay karne ki
zaroorat nahi — sab kuch GitHub ke free servers par hota hai.

---

## (Alternative) Android Studio se khud build karna
1. **Android Studio** install karein (Hedgehog ya usse naya version): https://developer.android.com/studio
2. Ye poora `WTranslate` folder Android Studio mein **Open** karein
   (File → Open → is folder ko select karein).
3. Studio Gradle sync khud karega (thora time lagega, internet chahiye
   sirf ek baar dependencies download karne ke liye).
4. Apne phone ko USB se connect karein (USB debugging ON honi chahiye:
   Settings → About Phone → Build Number par 7 baar tap karein → Developer
   Options → USB Debugging), ya ek emulator use karein.
5. Green **Run ▶** button dabayein — app phone par install ho jayega.

## Phone par setup (app khulne ke baad)
1. **"Urdu language model download karein"** button dabayein (Wi-Fi par karein,
   ye ek hi baar hota hai — model phone par save ho jata hai).
2. **"Display over other apps"** permission dein.
3. **"Accessibility Service ON karein"** — Settings khulegi, "WTranslate"
   dhoondh kar switch ON karein.
4. Ab WhatsApp kholein, kisi English message par tap karein — Urdu
   translation ek chhota bubble mein dikhega. Bubble ko tap karke band
   kar sakte hain.

## Zaroori baatein (limitations)
- Ye Android-only hai (iOS mein Accessibility Service is tarah kaam nahi karti).
- WhatsApp apne app ke updates ke sath UI structure kabhi kabhi badalta hai,
  isliye kabhi kabhi tap-detection thora adjust karna par sakta hai.
- Translation quality machine-translation jaisi hai (Google Translate offline
  mode jaisi) — chhote/casual messages ke liye acha kaam karta hai.
- Sab kuch device par hi hota hai — koi message kahin bahar nahi bheja jata.

## Files ka structure
```
app/src/main/java/com/wtranslate/app/
  MainActivity.kt                 -> permissions + model download screen
  WhatsAppAccessibilityService.kt -> WhatsApp ke taps detect karta hai
  TranslatorHelper.kt             -> ML Kit offline translation wrapper
  OverlayManager.kt               -> floating bubble dikhata hai
```
